import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
class Students implements Comparable<Students> {
String name;
 int age;
 String bloodgroup;
 String qualification;

  Students(String name, int age,   String bloodgroup, String qualification) 
{
    this.name = name;
    this.age = age;
    this.bloodgroup=bloodgroup;
this.qualification=qualification;
  }
  
  public String getName() {
    return this.name;
  }
  
  public int getAge() {
    return this.age;
  }
  
  public String getBloodgroup() {
    return this.bloodgroup;
  }
public String getQualification() {
  return this.qualification;
}
  
  @Override
  public int compareTo(Students students) {
    return this.age - students.age;
  }
  
  public String toString() {
    return this.name + " " + this.age + " " + this.bloodgroup+" "+this.qualification;
  }
}

class AgeComparator implements Comparator<Students> {
   
  @Override
  public int compare(Students std1, Students std2) {
      return std1.getAge() - std2.getAge();
  }
}

class QualificationComparator implements Comparator<Students> {
   
  @Override
  public int compare(Students std1, Students std2) {
      return std1.getQualification().compareTo(std2.getQualification());
  }
}

class NameComparator implements Comparator<Students> {
   
  @Override
  public int compare(Students std1, Students std2) {
      return std1.getName().compareTo(std2.getName());
  }
}
class BloodgroupComparator implements Comparator<Students> {
   
  @Override
  public int compare(Students std1, Students std2) {
      return std1.getBloodgroup().compareTo(std2.getBloodgroup());
  }
}

public class ComparingObjects {

  public static void main(String[] args) {

    int a[] = {7, 1, 80, 14};
    
    Arrays.sort(a);
    
    for(int i = 0; i < a.length; i++) {
      System.out.print(a[i] + " ");
    }
    
    System.out.println();
    System.out.println("//////////////////////////////////////////////");
    
    Students[] allStd = new Students[43];
        allStd[0]=new Students("Aruna",20,"A+","BSC");
        allStd[1]=new Students("anjali",21 ,"AB+" , "BCA");
        allStd[2]=new Students("devi", 18 , "AB-" ,"BA");
        allStd[3]=new Students("ramya",23 , "B+" , "MCA");
        allStd[4]=new Students("ishwarya",20 ,"AB-" , "MA");
        allStd[5]=new Students("vaishnavi",24 , "A+" ,  "BCA");
        allStd[6]=new Students("manoj",19 , "O+" , "BCA");
        allStd[7]=new Students("karthick", 18 ,"B+" , "BSC");
        allStd[8]=new Students("prabhu", 21 , "AB+" , "MA");
        allStd[9]=new Students("vijay", 23 ,"B+" ,"MCA");
        allStd[10]=new Students("vigneshwari", 20 , "A+" ,"BA");
        allStd[11]=new Students("babu", 19 , "B+" , "BA");
        allStd[12]=new Students( "mohan", 23 , "A+" , "MA");
        allStd[13]=new Students ("pavithra", 18 , "B+" , "MA");


     
    Arrays.sort(allStd);
    
    for(int i = 0; i < allStd.length; i++) {
      System.out.println(allStd[i] + " ");
    }
    
    System.out.println("//////////////////////////////////////////////");
    
    Arrays.sort(allStd, new AgeComparator());
    
    for(int i = 0; i < allStd.length; i++) {
      System.out.println(allStd[i] + " ");
    }
    
    System.out.println("//////////////////////////////////////////////");
    
    Arrays.sort(allStd, new NameComparator());
    
    for(int i = 0; i < allStd.length; i++) {
      System.out.println(allStd[i] + " ");
    }
    
    System.out.println("//////////////////////////////////////////////");
    
    Arrays.sort(allStd, new BloodgroupComparator());
    
    for(int i = 0; i < allStd.length; i++) {
      System.out.println(allStd[i] + " ");
    }
    
    System.out.println("//////////////////////////////////////////////");
    Arrays.sort(allStd, new QualificationComparator());
    
    for(int i = 0; i < allStd.length; i++) {
      System.out.println(allStd[i] + " ");
    }
    System.out.println("//////////////////////////////////////////////");

    
    List<Students> stdList = new ArrayList<>();
    
       stdList.add(new Students("Aruna",20,"A+","BSC"));
       stdList.add(new Students("anjali",21 ,"AB+" , "BCA"));
       stdList.add(new Students("devi", 18 , "AB-" ,"BA"));
	 stdList.add(new Students("ramya",23 , "B+" , "MCA"));
	 stdList.add(new Students("ishwarya",20 ,"AB-" , "MA"));
	 stdList.add(new Students("vaishnavi",24 , "A+" ,  "BCA"));
	 stdList.add(new Students("manoj",19 , "O+" , "BCA"));
	 stdList.add(new Students("karthick", 18 ,"B+" , "BSC"));
	 stdList.add(new Students("prabhu", 21 , "AB+" , "MA"));
	 stdList.add(new Students("vijay", 23 ,"B+" ,"MCA"));
	 stdList.add(new Students("vigneshwari", 20 , "A+" ,"BA"));
 	 stdList.add(new Students("babu", 19 , "B+" , "BA"));
	 stdList.add(new Students("mohan", 23 , "A+" , "MA"));
	 stdList.add(new Students("pavithra", 18 , "B+" , "MA"));

    
    Collections.sort(stdList);
    System.out.println(stdList);
    
    Collections.sort(stdList, new AgeComparator());
    System.out.println(stdList);

    Collections.sort(stdList, new NameComparator());
    System.out.println(stdList);


    Collections.sort(stdList, new BloodgroupComparator());
    System.out.println(stdList);



    Collections.sort(stdList, new QualificationComparator());
    System.out.println(stdList);

  }

}






